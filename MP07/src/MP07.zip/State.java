public interface State {

    void returnChanges();
    void SelectBevearge();
    void addHundread();
    void addFiveHundread();
    void addThousand();


}
