public interface Preprocessor {

    SourceCode preprocess(SourceCode code);
}
