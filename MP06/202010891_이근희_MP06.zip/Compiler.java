public interface Compiler {

    ObjectCode compile(SourceCode sc);

}
