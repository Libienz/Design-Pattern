interface Comparable {
    int compareTo(FileInfo o1, FileInfo o2);

}