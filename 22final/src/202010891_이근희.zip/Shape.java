public abstract class Shape implements Selectable{
    String shapeName;

    //public abstract void calcBounds(); //?

    //public abstract String getShapeName();

    public Shape () {

    }

    public Shape(String shapeName) {
        this.shapeName = shapeName;
    }









}
